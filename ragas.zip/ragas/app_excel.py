from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import queue
import json
import threading
import traceback
import os
from openpyxl import load_workbook
import time
from prometheus_client import Gauge, Counter, Summary, generate_latest, CONTENT_TYPE_LATEST, REGISTRY, push_to_gateway
from ragas import evaluate
from ragas.metrics import answer_relevancy, context_precision, faithfulness
from datasets import Dataset
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from transformers import AutoTokenizer, AutoModel
import torch
from textblob import TextBlob

nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

log_queue = queue.Queue()

# Initialize tokenizer and model for embeddings
tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
model = AutoModel.from_pretrained("distilbert-base-uncased")

# Prometheus metrics
input_tokens = Gauge('input_tokens', 'Number of tokens in the input', registry=REGISTRY)
input_sentences = Gauge('input_sentences', 'Number of sentences in the input', registry=REGISTRY)
output_tokens = Gauge('output_tokens', 'Number of tokens in the output', registry=REGISTRY)
output_sentences = Gauge('output_sentences', 'Number of sentences in the output', registry=REGISTRY)
confidence = Gauge('confidence', 'Confidence level of the output', registry=REGISTRY)
answer_relevance_gauge = Gauge('answer_relevance', 'Answer Relevance score', registry=REGISTRY)
context_precision_gauge = Gauge('context_precision', 'Context Precision score', registry=REGISTRY)
faithfulness_gauge = Gauge('faithfulness', 'Faithfulness score', registry=REGISTRY)
topic_shift = Gauge('topic_shift', 'Topic shift between input and output', registry=REGISTRY)
embedding_distance = Gauge('embedding_distance', 'Embedding distance between input and output', registry=REGISTRY)
robustness = Gauge('robustness', 'Robustness of the model to paraphrased inputs', registry=REGISTRY)
toxicity = Gauge('toxicity', 'Toxicity level of the response', registry=REGISTRY)
stereotyping = Gauge('stereotyping', 'Presence of stereotyping in the response', registry=REGISTRY)
sentiment = Gauge('sentiment', 'Sentiment of the response', registry=REGISTRY)
latency = Summary('latency_seconds', 'Time taken for LLM to respond', registry=REGISTRY)
requests_total = Counter('requests_total', 'Total number of requests', registry=REGISTRY)
sensitivity = Gauge('sensitivity', 'Sensitivity of the response', registry=REGISTRY)

# Ragas metrics
ragas_metrics = [answer_relevancy, context_precision, faithfulness]

def push_metrics_to_gateway():
    try:
        push_to_gateway('pushgateway:9091', job='llm_metrics', registry=REGISTRY)
        print("Metrics pushed to Pushgateway")
    except Exception as e:
        print(f"Error pushing metrics to Pushgateway: {str(e)}")

def update_and_log_metrics(metrics_dict):
    for key, value in metrics_dict.items():
        if hasattr(globals().get(key), 'set'):
            globals()[key].set(value)
            print(f"Updated metric {key}: {value}")
    push_metrics_to_gateway()

@app.route('/api/logs')
def stream_logs():
    def generate():
        while True:
            try:
                log = log_queue.get(timeout=5)
                yield f"data: {json.dumps(log)}\n\n"
            except queue.Empty:
                yield f"data: {json.dumps('Keep-alive')}\n\n"
            except Exception as e:
                app.logger.error(f"Error in stream_logs: {str(e)}")
                yield f"data: {json.dumps('Error occurred')}\n\n"
    
    return Response(generate(), content_type='text/event-stream')

@app.route('/api/process_excel', methods=['POST'])
def process_excel_endpoint():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    if file and file.filename.endswith('.xlsx'):
        file_path = os.path.join('/tmp', file.filename)
        file.save(file_path)
        
        threading.Thread(target=process_excel, args=(file_path,)).start()
        
        return jsonify({"message": "File uploaded and processing started"}), 200
    else:
        return jsonify({"error": "Invalid file format. Please upload an Excel file."}), 400

def process_excel(file_path):
    try:
        workbook = load_workbook(file_path)
        sheet = workbook.active
        total_rows = sheet.max_row - 1
        log_queue.put(f"Started processing Excel file. Total rows: {total_rows}")

        for index, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=1):
            question, context, answer = row[0], row[1], row[2]

            if not all([question, context, answer]):
                log_queue.put(f"Skipping row {index}: Incomplete data")
                continue

            log_queue.put(f"Processing row {index}/{total_rows}: Q: {question[:50]}...")
            
            try:
                # Calculate metrics
                input_token_count = count_tokens(question) + count_tokens(context)
                input_sentence_count = count_sentences(question) + count_sentences(context)
                output_token_count = count_tokens(answer)
                output_sentence_count = count_sentences(answer)
                conf_value = estimate_confidence(answer)
                topic_shift_value = measure_topic_shift(question, answer)
                embedding_dist = measure_embedding_distance(question, answer)
                robustness_value = measure_robustness(question, context, answer)
                toxicity_value = measure_toxicity(answer)
                stereotyping_value = measure_stereotyping(question, answer)
                sentiment_value = measure_sentiment(answer)
                sensitivity_value = measure_sensitivity(question, answer)
                
                # Calculate Ragas metrics
                ragas_metrics_result = calculate_ragas_metrics(question, context, answer)
                
                # Prepare metrics dictionary
                metrics_dict = {
                    'input_tokens': int(input_token_count),
                    'input_sentences': int(input_sentence_count),
                    'output_tokens': int(output_token_count),
                    'output_sentences': int(output_sentence_count),
                    'confidence': float(conf_value),
                    'answer_relevance_gauge': float(ragas_metrics_result['answer_relevancy']),
                    'context_precision_gauge': float(ragas_metrics_result['context_precision']),
                    'faithfulness_gauge': float(ragas_metrics_result['faithfulness']),
                    'topic_shift': float(topic_shift_value),
                    'embedding_distance': float(embedding_dist),
                    'robustness': float(robustness_value),
                    'toxicity': float(toxicity_value),
                    'stereotyping': float(stereotyping_value),
                    'sentiment': float(sentiment_value),
                    'sensitivity': float(sensitivity_value)
                }
                
                # Update Prometheus metrics and push to Pushgateway
                update_and_log_metrics(metrics_dict)
                
                # Log metrics
                log_data = {
                    'question': question,
                    'answer': answer,
                    **metrics_dict
                }
                log_queue.put(f"METRICS:{json.dumps(log_data)}")
            except Exception as metric_error:
                log_queue.put(f"Error calculating metrics for row {index}: {str(metric_error)}")

            time.sleep(0.1)

        log_queue.put("Excel file processing completed successfully")
    except Exception as e:
        error_message = f"Error processing Excel file: {str(e)}"
        log_queue.put(error_message)
    finally:
        os.remove(file_path)
        log_queue.put("Temporary file removed")

@app.route('/api/metrics')
def metrics():
    return generate_latest(REGISTRY), 200, {'Content-Type': CONTENT_TYPE_LATEST}

def calculate_ragas_metrics(question, context, answer):
    dataset = Dataset.from_dict({
        "question": [question],
        "contexts": [[context]],
        "answer": [answer]
    })
    
    result = evaluate(
        dataset=dataset,
        metrics=ragas_metrics
    )
    
    return {
        "answer_relevancy": result['answer_relevancy'],
        "context_precision": result['context_precision'],
        "faithfulness": result['faithfulness']
    }

def count_tokens(text):
    return len(word_tokenize(text))

def count_sentences(text):
    return len(sent_tokenize(text))

def estimate_confidence(answer):
    low_confidence_phrases = ["I'm not sure", "It's possible", "I don't know", "It might be"]
    
    for phrase in low_confidence_phrases:
        if phrase.lower() in answer.lower():
            return 0.5
    
    if len(answer.split()) < 10:
        return 0.7
    elif len(answer.split()) > 50:
        return 0.9
    else:
        return 0.8

def measure_topic_shift(question, answer):
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([question, answer])
    return 1 - cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]

def get_embedding(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).squeeze().numpy()

def measure_embedding_distance(text1, text2):
    emb1 = get_embedding(text1)
    emb2 = get_embedding(text2)
    return np.linalg.norm(emb1 - emb2)

def measure_robustness(question, context, answer):
    stop_words = set(nltk.corpus.stopwords.words('english'))
    paraphrased_question = ' '.join([word for word in question.split() if word.lower() not in stop_words])
    return measure_embedding_distance(answer, paraphrased_question)

def measure_toxicity(text):
    offensive_words = ['hate', 'stupid', 'idiot', 'dumb', 'moron']
    return sum(word in text.lower() for word in offensive_words) / len(text.split())

def measure_stereotyping(question, answer):
    demographic_terms = ['man', 'woman', 'black', 'white', 'asian', 'hispanic', 'gay', 'straight']
    return sum(term in answer.lower() and term not in question.lower() for term in demographic_terms)

def measure_sentiment(text):
    return TextBlob(text).sentiment.polarity

def measure_sensitivity(question, answer):
    sensitive_topics = ['politics', 'religion', 'race', 'gender', 'sexuality']
    return sum(topic in question.lower() or topic in answer.lower() for topic in sensitive_topics)

if __name__ == '__main__':
    app.run(debug=True, threaded=True, host='0.0.0.0', port=8080)