import os
from flask import Flask, request, jsonify
from prometheus_client import start_http_server, Gauge, generate_latest, CONTENT_TYPE_LATEST
from ragas import evaluate
from ragas.metrics import (
    answer_relevancy,
    context_precision,
    faithfulness
)
import openai
from datasets import Dataset

app = Flask(__name__)

# Set up Prometheus metrics
answer_relevance_gauge = Gauge('answer_relevance', 'Answer Relevance score')
context_precision_gauge = Gauge('context_precision', 'Context Precision score')
faithfulness_gauge = Gauge('faithfulness', 'Faithfulness score')

# Initialize OpenAI API
openai.api_key = os.getenv("OPENAI_API_KEY")

def qa_system(question, context):
    prompt = f"Context: {context}\n\nQuestion: {question}\n\nAnswer:"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant that answers questions based on the given context."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=150
    )
    return response.choices[0].message['content'].strip()

@app.route('/qa', methods=['POST'])
def qa_endpoint():
    data = request.json
    question = data.get('question')
    context = data.get('context')
    
    if not question or not context:
        return jsonify({"error": "Missing question or context"}), 400
    
    answer = qa_system(question, context)
    
    # Evaluate with Ragas
    evaluation_result = evaluate_qa_result(question, context, answer)
    
    # Update Prometheus metrics
    answer_relevance_gauge.set(evaluation_result['answer_relevancy'])
    context_precision_gauge.set(evaluation_result['context_precision'])
    faithfulness_gauge.set(evaluation_result['faithfulness'])
    
    return jsonify({
        "question": question,
        "context": context,
        "answer": answer,
        "evaluation": evaluation_result
    })

def evaluate_qa_result(question, context, answer):
    # Create a dataset for evaluation
    eval_dataset = Dataset.from_dict({
        "question": [question],
        "contexts": [[context]],  # Note: contexts is now a list of lists
        "answer": [answer]
    })
    
    result = evaluate(
        dataset=eval_dataset,
        metrics=[
            answer_relevancy,
            context_precision,
            faithfulness
        ]
    )
    return {
        "answer_relevancy": result['answer_relevancy'],
        "context_precision": result['context_precision'],
        "faithfulness": result['faithfulness']
    }

@app.route('/metrics')
def metrics():
    return generate_latest(), 200, {'Content-Type': CONTENT_TYPE_LATEST}

if __name__ == '__main__':
    start_http_server(8000)
    app.run(host='0.0.0.0', port=8080)