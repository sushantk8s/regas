import os
import time
from flask import Flask, request, jsonify
from prometheus_client import start_http_server, Gauge, Counter, Summary, generate_latest, CONTENT_TYPE_LATEST, REGISTRY
from ragas import evaluate
from ragas.metrics import (
    answer_relevancy,
    context_precision,
    faithfulness
)
import openai
from datasets import Dataset
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from transformers import AutoTokenizer, AutoModel
import torch
from textblob import TextBlob

nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

app = Flask(__name__)

# Initialize OpenAI API
openai.api_key = os.getenv("OPENAI_API_KEY")

# Load pre-trained model and tokenizer for embeddings
tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
model = AutoModel.from_pretrained("distilbert-base-uncased")

# Ragas metrics
ragas_metrics = [
    answer_relevancy,
    context_precision,
    faithfulness
]

# Set up Prometheus metrics
input_tokens = Gauge('input_tokens', 'Number of tokens in the input', registry=REGISTRY)
input_sentences = Gauge('input_sentences', 'Number of sentences in the input', registry=REGISTRY)
output_tokens = Gauge('output_tokens', 'Number of tokens in the output', registry=REGISTRY)
output_sentences = Gauge('output_sentences', 'Number of sentences in the output', registry=REGISTRY)
confidence = Gauge('confidence', 'Confidence level of the output', registry=REGISTRY)
answer_relevance = Gauge('answer_relevance', 'Answer Relevance score', registry=REGISTRY)
context_precision_gauge = Gauge('context_precision', 'Context Precision score', registry=REGISTRY)
faithfulness_gauge = Gauge('faithfulness', 'Faithfulness score', registry=REGISTRY)
topic_shift = Gauge('topic_shift', 'Topic shift between input and output', registry=REGISTRY)
embedding_distance = Gauge('embedding_distance', 'Embedding distance between input and output', registry=REGISTRY)
robustness = Gauge('robustness', 'Robustness of the model to paraphrased inputs', registry=REGISTRY)
toxicity = Gauge('toxicity', 'Toxicity level of the response', registry=REGISTRY)
stereotyping = Gauge('stereotyping', 'Presence of stereotyping in the response', registry=REGISTRY)
sentiment = Gauge('sentiment', 'Sentiment of the response', registry=REGISTRY)
latency = Summary('latency_seconds', 'Time taken for LLM to respond', registry=REGISTRY)
requests_total = Counter('requests_total', 'Total number of requests', registry=REGISTRY)
sensitivity = Gauge('sensitivity', 'Sensitivity of the response', registry=REGISTRY)

def count_tokens(text):
    return len(word_tokenize(text))

def count_sentences(text):
    return len(sent_tokenize(text))

def estimate_confidence(answer):
    low_confidence_phrases = ["I'm not sure", "It's possible", "I don't know", "It might be"]
    
    for phrase in low_confidence_phrases:
        if phrase.lower() in answer.lower():
            return 0.5
    
    if len(answer.split()) < 10:
        return 0.7
    elif len(answer.split()) > 50:
        return 0.9
    else:
        return 0.8

def qa_system(question, context):
    prompt = f"Context: {context}\n\nQuestion: {question}\n\nAnswer:"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant that answers questions based on the given context."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=150
    )
    answer = response.choices[0].message['content'].strip()
    confidence_value = estimate_confidence(answer)
    return answer, confidence_value

@app.route('/qa', methods=['POST'])
@latency.time()
def qa_endpoint():
    requests_total.inc()
    data = request.json
    question = data.get('question')
    context = data.get('context')
    
    if not question or not context:
        return jsonify({"error": "Missing question or context"}), 400
    
    input_tokens.set(count_tokens(question) + count_tokens(context))
    input_sentences.set(count_sentences(question) + count_sentences(context))
    
    answer, confidence_value = qa_system(question, context)
    
    output_tokens.set(count_tokens(answer))
    output_sentences.set(count_sentences(answer))
    confidence.set(confidence_value)
    
    evaluation_result = evaluate_qa_result(question, context, answer)
    
    answer_relevance.set(evaluation_result['answer_relevancy'])
    context_precision_gauge.set(evaluation_result['context_precision'])
    faithfulness_gauge.set(evaluation_result['faithfulness'])
    
    topic_shift.set(measure_topic_shift(question, answer))
    embedding_distance.set(measure_embedding_distance(question, answer))
    robustness.set(measure_robustness(question, context, answer))
    toxicity.set(measure_toxicity(answer))
    stereotyping.set(measure_stereotyping(question, answer))
    sentiment.set(measure_sentiment(answer))
    sensitivity.set(measure_sensitivity(question, answer))
    
    return jsonify({
        "question": question,
        "context": context,
        "answer": answer,
        "confidence": confidence_value,
        "evaluation": evaluation_result
    })

def evaluate_qa_result(question, context, answer):
    eval_dataset = Dataset.from_dict({
        "question": [question],
        "contexts": [[context]],
        "answer": [answer]
    })
    
    result = evaluate(
        eval_dataset,
        metrics=ragas_metrics
    )
    return {
        "answer_relevancy": result['answer_relevancy'],
        "context_precision": result['context_precision'],
        "faithfulness": result['faithfulness']
    }

def measure_topic_shift(question, answer):
    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = vectorizer.fit_transform([question, answer])
    cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    return 1 - cosine_sim[0][0]

def get_embedding(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).squeeze().numpy()

def measure_embedding_distance(text1, text2):
    emb1 = get_embedding(text1)
    emb2 = get_embedding(text2)
    return np.linalg.norm(emb1 - emb2)

def measure_robustness(question, context, answer):
    stop_words = set(stopwords.words('english'))
    paraphrased_question = ' '.join([word for word in question.split() if word.lower() not in stop_words])
    
    paraphrased_answer, _ = qa_system(paraphrased_question, context)
    return measure_embedding_distance(answer, paraphrased_answer)

def measure_toxicity(text):
    offensive_words = ['hate', 'stupid', 'idiot', 'dumb', 'moron']
    return sum(word in text.lower() for word in offensive_words) / len(text.split())

def measure_stereotyping(prompt, response):
    demographic_terms = ['man', 'woman', 'black', 'white', 'asian', 'hispanic', 'gay', 'straight']
    return sum(term in response.lower() and term not in prompt.lower() for term in demographic_terms)

def measure_sentiment(text):
    return TextBlob(text).sentiment.polarity

def measure_sensitivity(question, answer):
    sensitive_topics = ['politics', 'religion', 'race', 'gender', 'sexuality']
    return sum(topic in question.lower() or topic in answer.lower() for topic in sensitive_topics)

@app.route('/metrics')
def metrics():
    return generate_latest(REGISTRY), 200, {'Content-Type': CONTENT_TYPE_LATEST}

if __name__ == '__main__':
    start_http_server(8000)
    app.run(host='0.0.0.0', port=8080)