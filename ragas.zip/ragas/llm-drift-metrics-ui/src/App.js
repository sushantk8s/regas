import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [message, setMessage] = useState('');
  const [logs, setLogs] = useState([]);
  const [metrics, setMetrics] = useState([]);
  const eventSourceRef = useRef(null);
  const logContainerRef = useRef(null);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
    setLogs([]);
    setMessage('');
    setMetrics([]);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!file) {
      setMessage('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    setIsProcessing(true);
    setMessage('Processing file...');
    setLogs([]);
    setMetrics([]);

    try {
      await axios.post('/api/process_excel', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      startLogStream();
    } catch (error) {
      setMessage('Error processing file: ' + error.response?.data?.error || error.message);
      setIsProcessing(false);
    }
  };

  const startLogStream = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    eventSourceRef.current = new EventSource('/api/logs');
    
    eventSourceRef.current.onmessage = (event) => {
      const newLog = JSON.parse(event.data);
      if (newLog !== 'Keep-alive') {
        if (newLog.startsWith('METRICS:')) {
          const metricData = JSON.parse(newLog.slice(8));
          setMetrics(prevMetrics => [...prevMetrics, metricData]);
        } else {
          setLogs(prevLogs => [...prevLogs, newLog]);
        }
        
        if (newLog.includes("Excel file processing completed successfully") || 
            newLog.includes("Error processing Excel file")) {
          setIsProcessing(false);
          setMessage(newLog);
          eventSourceRef.current.close();
        }
      }
    };

    eventSourceRef.current.onerror = () => {
      setIsProcessing(false);
      eventSourceRef.current.close();
    };
  };

  useEffect(() => {
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, metrics]);

  return (
    <div className="container mt-5">
      <h1 className="mb-4">LLM Drift Metrics</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="fileInput" className="form-label">Upload qa_data.xlsx</label>
          <input
            type="file"
            className="form-control"
            id="fileInput"
            accept=".xlsx"
            onChange={handleFileChange}
            disabled={isProcessing}
          />
        </div>
        <button type="submit" className="btn btn-primary" disabled={isProcessing || !file}>
          {isProcessing ? 'Processing...' : 'Upload and Process'}
        </button>
      </form>
      {message && (
        <div className={`alert ${isProcessing ? 'alert-info' : 'alert-success'} mt-3`} role="alert">
          {message}
        </div>
      )}
      <div className="mt-5">
        <h3>Metrics and Logs:</h3>
        <div ref={logContainerRef} className="border p-3" style={{height: '400px', overflowY: 'scroll'}}>
          {logs.map((log, index) => (
            <div key={`log-${index}`}>{log}</div>
          ))}
          {metrics.map((metric, index) => (
            <div key={`metric-${index}`} className="mt-3 p-2 bg-light">
              <h5>Question: {metric.question}</h5>
              <p><strong>Answer:</strong> {metric.answer}</p>
              <div style={{color: 'red'}}>
                {Object.entries(metric).map(([key, value]) => {
                  if (key !== 'question' && key !== 'answer') {
                    return <div key={key}>{`${key}: ${typeof value === 'number' ? value.toFixed(4) : value}`}</div>
                  }
                  return null;
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;